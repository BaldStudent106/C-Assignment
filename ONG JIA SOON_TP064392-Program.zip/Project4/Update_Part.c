#include "Main.h"
//Lets user update the quantity of parts
int update_part() {
	//declare all variables
	FILE* f;
	struct Car
	{
		char partid[7];
		char name[30];
		int quantity;
	};

	struct Car Blaze[30];
	struct Car Silk[30];
	struct Car Armer[30];
	struct Car* structchoice[30];

	char filechoice[10];
	int choice, counter,i,part_choice,choice3,volume;

	//prompt user for model choice
	printf("\n\nWhich Model Would U like to update:\n");
	printf("1- Blaze\n");
	printf("2- Silk\n");
	printf("3- Armer\n");
	printf("Please enter your choice:\n");
	scanf("%d", &choice);

	//Assign structure pointer to structure according to model choice
	if (choice == 1) {
		strcpy(filechoice, "Blaze.txt");
		for (i = 0; i < 30; i++) {
			structchoice[i] = &Blaze[i];
	
		}
	}
	else if (choice == 2) {
		strcpy(filechoice, "Silk.txt");
		for (i = 0; i < 30; i++) {
			structchoice[i] = &Silk[i];
		}
	}
	else if (choice == 3) {
		strcpy(filechoice, "Armer.txt");
		for (i = 0; i < 30; i++) {
			structchoice[i] = &Armer[i];
		}
	}
	else {
		printf("Invalid Input!");
		return 0;
	}

	//readfile
	f = fopen(filechoice, "r");
	fscanf(f, "%d", &counter);
	if (counter > -1) {
		for (i = 0; i <= counter; i++) {
			fscanf(f, "%s", &structchoice[i]->partid);
			fscanf(f, "%s", &structchoice[i]->name);
			fscanf(f, "%d", &structchoice[i]->quantity);
		}
		fclose(f);
	}
	else
	{
		printf("No record");
	}

	//menu
	printf(" \n\n\t\t\t\t *****  INVENTORY *****\n");
	printf("------------------------------------------------------------------------------------\n");
	printf("No|		PART ID				|  NAME|			|	QUANTITY |						\n");
	printf("------------------------------------------------------------------------------------\n");
	for (i = 0; i <= counter; i++) {
		printf("%d-		%s				%s					%d\n", i + 1, structchoice[i]->partid, structchoice[i]->name, structchoice[i]->quantity);
	}

	//Select part to update
	printf("Which Part Would You Like to Update:\n");
	scanf("%d", &part_choice);
	if (part_choice > (counter + 1)) {
		printf("Invalid Input!");
		return 0;
	}

	//Select Increase or Decrease
	printf("Would You like to Increase Or Decrease:\n");
	printf("1-Increase\n");
	printf("2-Decrease\n");
	scanf("%d", &choice3);

	//increase quantity of parts
	if (choice3 == 1) {
		printf("How many would you like to increase:\n");
		scanf("%d", &volume);
		structchoice[part_choice - 1]->quantity+=volume;
		f = fopen(filechoice, "w");
		fprintf(f, "%d\n", counter);
		for (i = 0; i <= counter; i++) {
			fprintf(f, "%s\n", structchoice[i]->partid);
			fprintf(f, "%s\n", structchoice[i]->name);
			fprintf(f, "%d\n", structchoice[i]->quantity);
		}
		fclose(f);
		printf("\n\nAdded Successfully!");
	}

	//decrease quantity of parts
	else if (choice3 == 2) {
		printf("How much would you like to decrease:\n");
		scanf("%d", &volume);
		if (structchoice[part_choice - 1]->quantity < volume) {
			printf("\n\nNot Enough Stock");
		}
		else
		{
			structchoice[part_choice - 1]->quantity -= volume;
			printf("\n\nDecreased Successfully!");
		}
		f = fopen(filechoice, "w");
		fprintf(f, "%d\n", counter);
		for (i = 0; i <= counter; i++) {
			fprintf(f, "%s\n", structchoice[i]->partid);
			fprintf(f, "%s\n", structchoice[i]->name);
			fprintf(f, "%d\n", structchoice[i]->quantity);
		}
		fclose(f);
	}
	else
	{
		printf("Invalid Input!");
		return 0;
	}
	return 0;
}