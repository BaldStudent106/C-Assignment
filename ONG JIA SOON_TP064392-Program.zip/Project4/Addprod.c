#include "Main.h"
//Let user add more parts id
int addpart() {
	//declare all variable
	struct Car
	{
		char partid[7];
		char name[30];
		int quantity;
	};

	struct Car Blaze[30];
	struct Car Silk[30];
	struct Car Armer[30];
	struct Car* structchoice[30];

	struct Supplier {
		char supplierid[30];
		char partid[7];
		char name[30];
	};

	struct Supplier Blaze_Record[30];
	struct Supplier Silk_Record[30];
	struct Supplier Armer_Record[30];
	struct Supplier* structchoice2[30];


	FILE* f;
	int choice, counter, i;
	char filechoice[10];
	char filechoice2[20];
	char start[10];
	//prompt for user to choose model
	printf("Which Model\n");
	printf("1- Blaze\n");
	printf("2- Silk\n");
	printf("3- Armer\n");
	printf("Please enter your choice:\n");
	scanf("%d", &choice);
	//Assign structure pointer to structure according to model choice
	if (choice == 1) {
		strcpy(filechoice, "Blaze.txt");
		strcpy(filechoice2, "Blaze_Record.txt");
		strcpy(start,"BZ");
		for (i = 0; i < 30; i++) {
			structchoice[i] = &Blaze[i];
			structchoice2[i] = &Blaze_Record[i];
		}
	}
	else if (choice == 2) {
		strcpy(filechoice, "Silk.txt");
		strcpy(filechoice2, "Silk_Record.txt");
		strcpy(start, "SI");
		for (i = 0; i < 30; i++) {
			structchoice[i] = &Silk[i];
			structchoice2[i] = &Silk_Record[i];
		}
	}
	else if (choice == 3) {
		strcpy(filechoice, "Armer.txt");
		strcpy(filechoice2, "Armer_Record.txt");
		strcpy(start, "AR");
		for (i = 0; i < 30; i++) {
			structchoice[i] = &Armer[i];
			structchoice2[i] = &Armer_Record[i];
		}
	}
	else {
		printf("Invalid Input!");
		return 0;
	}
	//readfile or create file if file doesnot already exist
	f = fopen(filechoice, "r");
	if (f == NULL) {
		f = fopen(filechoice, "w");
		fprintf(f, "%d", -1);
	}
	fclose(f);
	f = fopen(filechoice, "r");
	fscanf(f, "%d", &counter);
	if (counter > -1) {
		for (i = 0; i <= counter; i++) {
			fscanf(f, "%s", &structchoice[i]->partid);
			fscanf(f, "%s", &structchoice[i]->name);
			fscanf(f, "%d", &structchoice[i]->quantity);
		}
	}
	fclose(f);
	//generate id for parts
	counter += 1;
	if (counter < 10) {
		char a[10] = "000";
		char num[5];
		sprintf(num, "%d", counter);
		strcat(a, num);
		strcat(start, a);
		strcpy(structchoice[counter]->partid, start);
	}
	else if (counter >= 10 && counter < 30) {
		char a[10] = "00";
		char num[5];
		sprintf(num, "%d", counter);
		strcat(a, num);
		strcat(start, a);
		strcpy(structchoice[counter]->partid, start);
	}
	//prompt user for parts information
	printf("Please enter the part name:\n");
	scanf("%s", &structchoice[counter]->name);
	printf("Please enter quantity:\n");
	scanf("%d", &structchoice[counter]->quantity);
	printf("Please Enter Supplier ID:\n");
	scanf("%s", &structchoice2[counter]->supplierid);
	//write parts info into their txt files
	f = fopen(filechoice, "w");
	fprintf(f, "%d\n", counter);
	for (i = 0; i <= counter; i++) {
	fprintf(f, "%s\n", structchoice[i]->partid);
	fprintf(f, "%s\n", structchoice[i]->name);
	fprintf(f, "%d\n", structchoice[i]->quantity);
	}
	fclose(f);
	//write supplier info into supplier files
	f = fopen(filechoice2, "a");
	fprintf(f, "%s\n", structchoice2[counter]->supplierid);
	fprintf(f, "%s\n", structchoice[counter]->partid);
	fprintf(f, "%s\n", structchoice[counter]->name);
	fclose(f);
	printf("\n\nAdded Successfully!\n\n");
	return 0;
}