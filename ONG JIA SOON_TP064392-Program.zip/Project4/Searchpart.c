#include"Main.h"

//Search for parts record using parts id
int searchpart() {
	//declare all variables
	FILE* f;
	int counter, i, result;
	struct Car
	{
		char partid[7];
		char name[30];
		int quantity;
	};

	struct Car Blaze[30];
	struct Car Silk[30];
	struct Car Armer[30];
	char id[20];
	printf("Please enter the parts ID:\n");
	scanf("%s", &id);

	printf(" \n\n\t\t\t\t *****  INVENTORY *****\n");
	printf("------------------------------------------------------------------------------------\n");
	printf("No|		PART ID				|  NAME|			|	QUANTITY |						\n");
	printf("------------------------------------------------------------------------------------\n");
	
	//readfiles and search parts to print
	f = fopen("Blaze.txt", "r");
	fscanf(f, "%d", &counter);
	for (i = 0; i <= counter; i++) {
		fscanf(f, "%s", &Blaze[i].partid);
		fscanf(f, "%s", &Blaze[i].name);
		fscanf(f, "%d", &Blaze[i].quantity);
	}
	fclose(f);
	for (i = 0; i <= counter; i++) {
		if (strcmp(Blaze[i].partid, id) == 0)
		{
			printf("%d-		%s				%s					%d\n", i + 1, Blaze[i].partid, Blaze[i].name, Blaze[i].quantity);

		}

	}
	//readfiles and search parts to print
	f = fopen("Silk.txt", "r");
	fscanf(f, "%d", &counter);
	for (i = 0; i <= counter; i++) {
		fscanf(f, "%s", &Silk[i].partid);
		fscanf(f, "%s", &Silk[i].name);
		fscanf(f, "%d", &Silk[i].quantity);
	}
	fclose(f);
	for (i = 0; i <= counter; i++) {
		if (strcmp(Silk[i].partid, id) == 0)
		{
			printf("%d-		%s				%s					%d\n", i + 1, Silk[i].partid, Silk[i].name, Silk[i].quantity);
		}

	}
	//readfiles and search parts to print
	f = fopen("Armer.txt", "r");
	fscanf(f, "%d", &counter);
	for (i = 0; i <= counter; i++) {
		fscanf(f, "%s", &Armer[i].partid);
		fscanf(f, "%s", &Armer[i].name);
		fscanf(f, "%d", &Armer[i].quantity);
	}
	fclose(f);
	for (i = 0; i <= counter; i++) {
		if (strcmp(Silk[i].partid, id) == 0)
		{
			printf("%d-		%s				%s					%d\n", i + 1, Armer[i].partid, Armer[i].name, Armer[i].quantity);
		}

	}
}
	