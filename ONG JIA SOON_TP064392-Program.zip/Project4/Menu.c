#include "Main.h"
//Display menu and return choice
int menu() {
	int choice;
	printf("\n\t\t\t Inventory Management System\n");
	printf("Menu\n");
	printf("___________\n");
	printf("1- Input New Parts\n");
	printf("2- Update Parts\n");
	printf("3- Print All Parts\n");
	printf("4- Print Parts With Less Than 10 Remaining\n");
	printf("5- Search for Part's Record\n");
	printf("6- Search for Supplier\n");
	printf("7- Delete a Product\n");
	printf("8- Exit\n");
	printf("Please enter your choice:\n");
	scanf("%d", &choice);
	return(choice);
}
