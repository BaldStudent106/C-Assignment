#include "Main.h"

//printf all with less then 10 remaining
int printften() {
	//declare all variables
	struct Car
	{
		char partid[7];
		char name[30];
		int quantity;
	};

	struct Car Blaze[30];
	struct Car Silk[30];
	struct Car Armer[30];
	struct Car* structchoice[30];
	int choice,counter,i;
	char filechoice[10];
	FILE* f;
	//menu
	printf("Warehouse Choice\n");
	printf("1- Blaze\n");
	printf("2- Silk\n");
	printf("3-Armer\n");
	scanf("%d", &choice);
	//Assign structure pointer to structure according to model choice
	if (choice == 1) {
		strcpy(filechoice, "Blaze.txt");
		for (i = 0; i < 30; i++) {
			structchoice[i] = &Blaze[i];
		}
	}
	else if (choice == 2) {
		strcpy(filechoice, "Silk.txt");
		for (i = 0; i < 30; i++) {
			structchoice[i] = &Silk[i];
		}
	}
	else if (choice == 3) {
		strcpy(filechoice, "Armer.txt");
		for (i = 0; i < 30; i++) {
			structchoice[i] = &Armer[i];
		}
	}
	else {
		printf("Invalid Input!");
		return 0;
	}
	//readfile
	f = fopen(filechoice, "r");
	fscanf(f, "%d", &counter);
	for (i = 0; i <= counter; i++) {
		fscanf(f, "%s", &structchoice[i]->partid);
		fscanf(f, "%s", &structchoice[i]->name);
		fscanf(f, "%d", &structchoice[i]->quantity);
	}
	fclose(f);
	//printf parts record
	printf(" \n\n\t\t\t\t *****  INVENTORY *****\n");
	printf("------------------------------------------------------------------------------------\n");
	printf("No|		PART ID				|  NAME|			|	QUANTITY |						\n");
	printf("------------------------------------------------------------------------------------\n");
	for (i = 0; i <= counter; i++) {
		if ((structchoice[i]->quantity) <= 10) {
			printf("%d-		%s				%s					%d\n", i + 1, structchoice[i]->partid, structchoice[i]->name, structchoice[i]->quantity);
		}
	}
	return 0;
}