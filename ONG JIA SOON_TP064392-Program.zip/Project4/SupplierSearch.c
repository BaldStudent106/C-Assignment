#include"Main.h"
//Search for supplier record with supplier id
int suppliersearch() {
	//Assign structure pointer to structure according to model choice
	FILE* f;
	FILE* a;
	char id[20];
	printf("Please enter the supplier ID:\n");
	scanf("%s", &id);
	int counter, i;
	struct Supplier {
		char supplierid[30];
		char partid[7];
		char name[30];
	};

	struct Supplier Blaze_Record[30];
	struct Supplier Silk_Record[30];
	struct Supplier Armer_Record[30];

	printf(" \n\n\t\t\t\t *****  SUPPLIER *****\n");
	printf("------------------------------------------------------------------------------------\n");
	printf("No|		SUPPLIER ID				|  PARTS ID|			|	NAME|						\n");
	printf("------------------------------------------------------------------------------------\n");
	//readfile and search supplier record to print
	a = fopen("Blaze.txt", "r");
	f = fopen("Blaze_Record.txt", "r");
	fscanf(a, "%d", &counter);
	if (counter > -1) {
		for (i = 0; i <= counter; i++) {
			fscanf(f, "%s", &Blaze_Record[i].supplierid);
			fscanf(f, "%s", &Blaze_Record[i] .partid);
			fscanf(f, "%s", &Blaze_Record[i].name);

		}
		fclose(f);
		fclose(a);
		for (i = 0; i <= counter; i++) {
			if (strcmp(Blaze_Record[i].partid, id) == 0)
			{
				printf("%d-		%s				%s					%s\n", i + 1, Blaze_Record[i].supplierid, Blaze_Record[i].partid, Blaze_Record[i].name);
			}
		}
	}
	a = fopen("Silk.txt", "r");
	f = fopen("Silk_Record.txt", "r");
	fscanf(a, "%d", &counter);
	if (counter > -1) {
		for (i = 0; i <= counter; i++) {
			fscanf(f, "%s", &Silk_Record[i].supplierid);
			fscanf(f, "%s", &Silk_Record[i].partid);
			fscanf(f, "%s", &Silk_Record[i].name);

		}
		fclose(f);
		fclose(a);
		for (i = 0; i <= counter; i++) {
			if (strcmp(Silk_Record[i].partid, id) == 0)
			{
				printf("%d-		%s				%s					%s\n", i + 1, Silk_Record[i].supplierid, Silk_Record[i].partid, Silk_Record[i].name);
			}
		}
	}
	a = fopen("Armer.txt", "r");
	f = fopen("Armer_Record.txt", "r");
	fscanf(a, "%d", &counter);
	if (counter > -1) {
		for (i = 0; i <= counter; i++) {
			fscanf(f, "%s", &Armer_Record[i].supplierid);
			fscanf(f, "%s", &Armer_Record[i].partid);
			fscanf(f, "%s", &Armer_Record[i].name);

		}
		fclose(f);
		fclose(a);
		for (i = 0; i <= counter; i++) {
			if (strcmp(Armer_Record[i].partid, id) == 0)
			{
				printf("%d-		%s				%s					%s\n", i + 1, Armer_Record[i].supplierid, Armer_Record[i].partid, Armer_Record[i].name);
			}
		}
	}
	fclose(f);
}
		