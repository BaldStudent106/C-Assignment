#include "Main.h"

int start() {
	int menu_select;
	for(;;){
		//Display menu and return choice
		menu_select = menu();
		//Run the program according to users choice
		option(menu_select);
	} 
	return 0;
}