//TP064392	//ONG JIA SOON
#include "Main.h"
#include "Menu.h"
#include "Options.h"
#include "Addprod.h"
#include "Update.h"
#include "PrintAll.h"
#include "PrintTen.h"
#include "SearchPart.h"
#include "SupplierSearch.h"
#include "Deleteprod.h"

//Main function to start the program
int main() {
	//function to start menu
	start();
}