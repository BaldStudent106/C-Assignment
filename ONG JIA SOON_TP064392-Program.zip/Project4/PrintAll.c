#include"Main.h"
//printf all according to part id
int printfall() {
	//declare all variables
	FILE* f;
	int counter, counter2, counter3, total, i, j;
	struct Car
	{
		char partid[100];
		char name[20];
		int quantity;
	};
	struct Car All[90];
	struct Car temp;
	//readfiles
	f = fopen("Blaze.txt", "r");
	fscanf(f, "%d", &counter);
	for (i = 0; i <= counter; i++) {
		fscanf(f, "%s", &All[i].partid);
		fscanf(f, "%s", &All[i].name);
		fscanf(f, "%d", &All[i].quantity);
	}
	fclose(f);
	f = fopen("Silk.txt", "r");
	fscanf(f, "%d", &counter2);
	if (counter2 > -1) {
		for (i = counter+1; i <= counter + counter2+1; i++) {
			fscanf(f, "%s", &All[i].partid);
			fscanf(f, "%s", &All[i].name);
			fscanf(f, "%d", &All[i].quantity);
		}
	}
	fclose(f);
	f = fopen("Armer.txt", "r");
	fscanf(f, "%d", &counter3);
	if (counter3 > -1) {
		for (i = counter + 1+counter2+1; i <= counter  + counter2 + 1+counter3+1; i++) {
			fscanf(f, "%s", &All[i].partid);
			fscanf(f, "%s", &All[i].name);
			fscanf(f, "%d", &All[i].quantity);
		}
	}
	fclose(f);
	//start bubble sort
	for (i = 0; i <= counter + counter2 + 1 + counter3 + 1; i++) {
		for (j = 0; j < (counter + 1 + counter2 + 1 + counter3 + 1) - 1; j++) {
			if (strcmp(All[j].partid, All[j + 1].partid) > 0) {
				temp = All[j];
				All[j] = All[j + 1];
				All[j + 1] = temp;
			}
		}
	}
	//print bubble sorted structure
	printf(" \n\n\t\t\t\t *****  INVENTORY *****\n");
	printf("------------------------------------------------------------------------------------\n");
	printf("No|		PART ID				|  NAME|			|	QUANTITY |						\n");
	printf("------------------------------------------------------------------------------------\n");
	for (i = 0; i < counter + 1 + counter2 + 1 + counter3 + 1; i++) {
		printf("%d-		%s				%s						%d\n", i + 1, All[i].partid, All[i].name, All[i].quantity);
	}
	return 0;
}

	