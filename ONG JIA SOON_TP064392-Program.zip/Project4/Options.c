int option(int choice){
	switch (choice)
	{
	case 1:
		//To let user add more parts id
		addpart();
		break;
	case 2:
		//Lets user update the quantity of parts
		update_part();
		break;
	case 3:
		//printf all sorted by part id
		printfall();
		break;
	case 4:
		//printf all with less then 10 remaining
		printften();
		break;
	case 5:
		//Search for parts record using parts id
		searchpart();
		break;
	case 6:
		//Search for supplier record with supplier id
		suppliersearch();
		break;
	case 7:
		//Delete a Parts Record
		deleteproduct();
		break;
	case 8:
		//Edit a Parts Record
		printf("Goodbye!");
		exit(0);		
	default:
		printf("Invalid Input!");
		break;
	}
	return 0;
}