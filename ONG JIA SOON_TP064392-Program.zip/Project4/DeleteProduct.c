#include "Main.h"
//Delete a Parts Record
int deleteproduct() {
	//declare all variable
	struct Car
	{
		char partid[7];
		char name[30];
		int quantity;
	};

	struct Car Blaze[30];
	struct Car Silk[30];
	struct Car Armer[30];
	struct Car* structchoice[30];

	struct Supplier {
		char supplierid[30];
		char partid[7];
		char name[30];
	};

	struct Supplier Blaze_Record[30];
	struct Supplier Silk_Record[30];
	struct Supplier Armer_Record[30];
	struct Supplier* structchoice2[30];

	int counter, choice,i,j,id;
	FILE* f;
	//prompt for user to choose model
	printf("Please Select Warehouse:\n");
	printf("1- Blaze\n");
	printf("2- Silk\n");
	printf("3- Armer\n");
	scanf("%d", &choice);
	char filechoice[20];
	char filechoice2[20];
	//Assign structure pointer to structure according to model choice
	if (choice == 1) {
		strcpy(filechoice, "Blaze.txt");
		strcpy(filechoice2, "Blaze_Record.txt");
		for (i = 0; i < 30; i++) {
			structchoice[i] = &Blaze[i];
			structchoice2[i] = &Blaze_Record[i];
		}
	}
	else if (choice == 2) {
		strcpy(filechoice, "Silk.txt");
		strcpy(filechoice2, "Silk_Record.txt");
		for (i = 0; i < 30; i++) {
			structchoice[i] = &Silk[i];
			structchoice2[i] = &Silk_Record[i];
		}
	}
	else if (choice == 3) {
		strcpy(filechoice, "Armer.txt");
		strcpy(filechoice2, "Armer_Record.txt");
		for (i = 0; i < 30; i++) {
			structchoice[i] = &Armer[i];
			structchoice2[i] = &Armer_Record[i];
		}
	}
	//readfile
	f = fopen(filechoice, "r");
	fscanf(f, "%d", &counter);
	if (counter > -1) {
		for (i = 0; i <= counter; i++) {
			fscanf(f, "%s", &structchoice[i]->partid);
			fscanf(f, "%s", &structchoice[i]->name);
			fscanf(f, "%d", &structchoice[i]->quantity);
		}
	}
	else {
		printf("No parts recorded");
		return 0;
	}
	fclose(f);
	f = fopen(filechoice2, "r");
	if (counter > -1) {
		for (i = 0; i <= counter; i++) {
			fscanf(f, "%s", &structchoice2[i]->supplierid);
			fscanf(f, "%s", &structchoice2[i]->partid);
			fscanf(f, "%s", &structchoice2[i]->name);
		}
	}
	fclose(f);
	//menu
	printf(" \n\n\t\t\t\t *****  INVENTORY *****\n");
	printf("------------------------------------------------------------------------------------\n");
	printf("No|		PART ID				|  NAME|			|	QUANTITY |						\n");
	printf("------------------------------------------------------------------------------------\n");
	for (i = 0; i <= counter; i++) {
		printf("%d-		%s				%s					%d\n", i + 1, structchoice[i]->partid, structchoice[i]->name, structchoice[i]->quantity);
	}
	//delete parts record
	printf("\nPlease select no:\n");
	scanf("%d", &id);
	for (i = id-1; i < counter; i++) {
		structchoice[i] = structchoice[i + 1];
	}
	for (i=id-1; i < counter; i++) {
		structchoice2[i] = structchoice2[i + 1];
	}
	counter--;
	//writefile
	f = fopen(filechoice, "w");
	fprintf(f, "%d\n", counter);
	for (i = 0; i <= counter; i++) {
		fprintf(f, "%s\n", structchoice[i]->partid);
		fprintf(f, "%s\n", structchoice[i]->name);
		fprintf(f, "%d\n", structchoice[i]->quantity);
	}
	fclose(f);
	f = fopen(filechoice2, "w");
	for (i = 0; i <= counter; i++) {
		fprintf(f, "%s\n", structchoice2[counter]->supplierid);
		fprintf(f, "%s\n", structchoice[counter]->partid);
		fprintf(f, "%s\n", structchoice[i]->name);
	}
	fclose(f);
	printf("Deleted Successfully!");
	return 0;
}